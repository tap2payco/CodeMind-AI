import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { AIAssistant } from "@/components/AIAssistant/AIAssistant";
import { Card, CardContent } from '@/components/ui/card';
import { Brain, Code2 } from 'lucide-react';

const Index = () => {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth');
    }
  }, [user, loading, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="flex flex-col items-center justify-center p-8 space-y-4">
            <div className="flex items-center space-x-2">
              <Brain className="h-8 w-8 text-primary animate-pulse" />
              <Code2 className="h-8 w-8 text-accent animate-pulse" />
            </div>
            <p className="text-muted-foreground">Loading...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!user) {
    return null; // Will redirect to auth
  }

  return <AIAssistant />;
};

export default Index;
