import { useLocation, Link } from "react-router-dom";
import { useEffect } from "react";
import { Home, Code, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="max-w-md w-full text-center space-y-6">
        {/* Error Code */}
        <div className="space-y-2">
          <div className="text-8xl font-bold bg-gradient-primary bg-clip-text text-transparent">
            404
          </div>
          <h1 className="text-2xl font-bold text-foreground">Page Not Found</h1>
          <p className="text-muted-foreground">
            The page you're looking for doesn't exist or has been moved.
          </p>
        </div>

        {/* AI Assistant Icon */}
        <div className="flex justify-center">
          <div className="p-4 bg-muted rounded-full">
            <Code className="h-12 w-12 text-primary" />
          </div>
        </div>

        {/* Actions */}
        <div className="space-y-3">
          <Button asChild className="w-full">
            <Link to="/">
              <Home className="h-4 w-4 mr-2" />
              Back to AI Assistant
            </Link>
          </Button>
          
          <Button variant="outline" asChild className="w-full">
            <Link to="/" onClick={() => window.history.back()}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Go Back
            </Link>
          </Button>
        </div>

        {/* Help Text */}
        <div className="text-xs text-muted-foreground">
          <p>If you believe this is an error, please check the URL or</p>
          <p>return to the main application.</p>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
