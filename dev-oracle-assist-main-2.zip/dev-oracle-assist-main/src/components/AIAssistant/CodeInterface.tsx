import { useState, useRef, useEffect } from "react";
import { Play, Wand2, HelpCircle, Zap, RotateCcw, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Message } from "./Message";
import { cn } from "@/lib/utils";

interface CodeMessage {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
}

interface CodeInterfaceProps {
  messages: CodeMessage[];
  onCodeAction: (action: string, code: string, language: string) => void;
  isLoading: boolean;
}

const languages = [
  { value: 'javascript', label: 'JavaScript' },
  { value: 'typescript', label: 'TypeScript' },
  { value: 'python', label: 'Python' },
  { value: 'java', label: 'Java' },
  { value: 'csharp', label: 'C#' },
  { value: 'cpp', label: 'C++' },
  { value: 'rust', label: 'Rust' },
  { value: 'go', label: 'Go' },
  { value: 'sql', label: 'SQL' },
  { value: 'html', label: 'HTML' },
  { value: 'css', label: 'CSS' }
];

const initialCode = `# Welcome to Code Mode!
# Enter your code here and I'll help you with it

def fibonacci(n):
    """Generate Fibonacci sequence up to n numbers"""
    sequence = [0, 1]
    
    for i in range(2, n):
        next_num = sequence[i-1] + sequence[i-2]
        sequence.append(next_num)
    
    return sequence

# Example usage
print("First 10 Fibonacci numbers:")
print(fibonacci(10))`;

export function CodeInterface({ messages, onCodeAction, isLoading }: CodeInterfaceProps) {
  const [code, setCode] = useState(initialCode);
  const [language, setLanguage] = useState('python');
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-scroll messages to bottom
  useEffect(() => {
    if (scrollAreaRef.current) {
      const scrollElement = scrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollElement) {
        scrollElement.scrollTop = scrollElement.scrollHeight;
      }
    }
  }, [messages, isLoading]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.max(200, textareaRef.current.scrollHeight)}px`;
    }
  }, [code]);

  const handleAction = (action: string) => {
    if (code.trim()) {
      onCodeAction(action, code.trim(), language);
    }
  };

  const clearCode = () => {
    setCode('');
  };

  const downloadCode = () => {
    const extension = getFileExtension(language);
    const blob = new Blob([code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `code.${extension}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const getFileExtension = (lang: string) => {
    const extensions: Record<string, string> = {
      javascript: 'js',
      typescript: 'ts',
      python: 'py',
      java: 'java',
      csharp: 'cs',
      cpp: 'cpp',
      rust: 'rs',
      go: 'go',
      sql: 'sql',
      html: 'html',
      css: 'css'
    };
    return extensions[lang] || 'txt';
  };

  return (
    <div className="flex h-full">
      {/* Code Editor */}
      <div className="flex-1 flex flex-col border-r border-border">
        <div className="border-b border-border p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold">Code Editor</h3>
            <div className="flex items-center gap-2">
              <Select value={language} onValueChange={setLanguage}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {languages.map((lang) => (
                    <SelectItem key={lang.value} value={lang.value}>
                      {lang.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Button variant="outline" size="sm" onClick={downloadCode}>
                <Download className="h-4 w-4" />
              </Button>
              
              <Button variant="outline" size="sm" onClick={clearCode}>
                <RotateCcw className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
            <Button
              variant="default"
              size="sm"
              onClick={() => handleAction('generate')}
              disabled={isLoading}
              className="gap-2"
            >
              <Wand2 className="h-4 w-4" />
              Generate
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleAction('explain')}
              disabled={isLoading || !code.trim()}
              className="gap-2"
            >
              <HelpCircle className="h-4 w-4" />
              Explain
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleAction('optimize')}
              disabled={isLoading || !code.trim()}
              className="gap-2"
            >
              <Zap className="h-4 w-4" />
              Optimize
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleAction('debug')}
              disabled={isLoading || !code.trim()}
              className="gap-2"
            >
              <Play className="h-4 w-4" />
              Debug
            </Button>
          </div>
        </div>
        
        <div className="flex-1 p-4">
          <Textarea
            ref={textareaRef}
            value={code}
            onChange={(e) => setCode(e.target.value)}
            placeholder="Enter your code here..."
            className={cn(
              "min-h-full font-mono text-sm resize-none border-0 focus-visible:ring-0",
              "bg-code-bg text-foreground"
            )}
            disabled={isLoading}
          />
        </div>
      </div>

      {/* AI Response Area */}
      <div className="w-1/2 flex flex-col">
        <div className="border-b border-border p-4">
          <h3 className="font-semibold">AI Assistant</h3>
          <p className="text-sm text-muted-foreground">
            Code analysis, explanations, and suggestions
          </p>
        </div>
        
        <ScrollArea ref={scrollAreaRef} className="flex-1 p-4">
          <div className="space-y-6">
            {messages.length === 0 ? (
              <div className="text-center py-12">
                <div className="text-4xl mb-4">🤖</div>
                <h3 className="text-lg font-semibold mb-2">Welcome to Code Mode</h3>
                <p className="text-muted-foreground">
                  I can help you generate, explain, optimize, and debug code. 
                  Enter your code and choose an action to get started!
                </p>
              </div>
            ) : (
              <>
                {messages.map((message) => (
                  <Message
                    key={message.id}
                    content={message.content}
                    role={message.role}
                    timestamp={message.timestamp}
                  />
                ))}
                {isLoading && (
                  <Message
                    content=""
                    role="assistant"
                    timestamp={new Date()}
                    isThinking={true}
                  />
                )}
              </>
            )}
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}