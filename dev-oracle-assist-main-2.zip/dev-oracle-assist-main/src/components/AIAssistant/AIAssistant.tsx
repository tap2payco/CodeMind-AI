import { useState, useEffect } from "react";
import { Header } from "./Header";
import { Sidebar } from "./Sidebar";
import { ModeSelector } from "./ModeSelector";
import { ChatInterface } from "./ChatInterface";
import { CodeInterface } from "./CodeInterface";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";

interface ChatMessage {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
}

interface CodeMessage {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
}

interface Conversation {
  id: string;
  title: string;
  lastMessage: string;
  timestamp: Date;
  mode: 'chat' | 'code';
  chatMessages: ChatMessage[];
  codeMessages: CodeMessage[];
}

export function AIAssistant() {
  const [activeMode, setActiveMode] = useState<'chat' | 'code'>('chat');
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const { toast } = useToast();
  const { user } = useAuth();

  // Load conversations from localStorage temporarily (will be from database later)
  useEffect(() => {
    const saved = localStorage.getItem('ai_conversations');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setConversations(parsed.map((conv: any) => ({
          ...conv,
          timestamp: new Date(conv.timestamp),
          chatMessages: conv.chatMessages?.map((msg: any) => ({
            ...msg,
            timestamp: new Date(msg.timestamp)
          })) || [],
          codeMessages: conv.codeMessages?.map((msg: any) => ({
            ...msg,
            timestamp: new Date(msg.timestamp)
          })) || []
        })));
      } catch (error) {
        console.error('Failed to load conversations:', error);
      }
    }
  }, []);

  // Save conversations to localStorage
  useEffect(() => {
    if (conversations.length > 0) {
      localStorage.setItem('ai_conversations', JSON.stringify(conversations));
    }
  }, [conversations]);

  const getCurrentConversation = () => {
    return conversations.find(conv => conv.id === activeConversationId);
  };

  const createNewConversation = () => {
    const newConv: Conversation = {
      id: `conv_${Date.now()}`,
      title: `New ${activeMode} conversation`,
      lastMessage: '',
      timestamp: new Date(),
      mode: activeMode,
      chatMessages: [],
      codeMessages: []
    };
    
    setConversations(prev => [newConv, ...prev]);
    setActiveConversationId(newConv.id);
  };

  const deleteConversation = (id: string) => {
    setConversations(prev => prev.filter(conv => conv.id !== id));
    if (activeConversationId === id) {
      setActiveConversationId(null);
    }
  };

  const updateConversation = (id: string, updates: Partial<Conversation>) => {
    setConversations(prev => prev.map(conv => 
      conv.id === id ? { ...conv, ...updates } : conv
    ));
  };

  // Call AI service using edge function
  const callAIService = async (messages: { role: string; content: string }[], mode: 'chat' | 'code'): Promise<string> => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        throw new Error('Not authenticated');
      }

      const response = await supabase.functions.invoke('chat-completion', {
        body: { 
          messages,
          mode
        },
        headers: {
          Authorization: `Bearer ${session.access_token}`,
        },
      });

      if (response.error) {
        throw new Error(response.error.message || 'Failed to get AI response');
      }

      return response.data.choices[0].message.content;
    } catch (error) {
      console.error('AI Service Error:', error);
      throw error;
    }
  };

  const handleSendMessage = async (message: string) => {
    if (!message.trim()) return;

    let currentConv = getCurrentConversation();
    if (!currentConv) {
      createNewConversation();
      currentConv = conversations.find(conv => conv.id === activeConversationId);
      if (!currentConv) return;
    }

    const userMessage: ChatMessage = {
      id: `msg_${Date.now()}`,
      content: message,
      role: 'user',
      timestamp: new Date()
    };

    // Add user message
    const updatedChatMessages = [...currentConv.chatMessages, userMessage];
    updateConversation(currentConv.id, {
      chatMessages: updatedChatMessages,
      lastMessage: message,
      timestamp: new Date(),
      title: currentConv.title === `New ${activeMode} conversation` 
        ? message.slice(0, 50) + (message.length > 50 ? '...' : '')
        : currentConv.title
    });

    // Check if user is authenticated
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to continue.",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);

    try {
      const messagesToSend = updatedChatMessages.map(msg => ({
        role: msg.role,
        content: msg.content
      }));
      
      const aiResponse = await callAIService(messagesToSend, 'chat');
      
      const assistantMessage: ChatMessage = {
        id: `msg_${Date.now()}_ai`,
        content: aiResponse,
        role: 'assistant',
        timestamp: new Date()
      };

      updateConversation(currentConv.id, {
        chatMessages: [...updatedChatMessages, assistantMessage]
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to get AI response. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCodeAction = async (action: string, code: string, language: string) => {
    let currentConv = getCurrentConversation();
    if (!currentConv) {
      createNewConversation();
      currentConv = conversations.find(conv => conv.id === activeConversationId);
      if (!currentConv) return;
    }

    const userMessage: CodeMessage = {
      id: `msg_${Date.now()}`,
      content: `**Action:** ${action}\n**Language:** ${language}\n\n\`\`\`${language}\n${code}\n\`\`\``,
      role: 'user',
      timestamp: new Date()
    };

    const updatedCodeMessages = [...currentConv.codeMessages, userMessage];
    updateConversation(currentConv.id, {
      codeMessages: updatedCodeMessages,
      lastMessage: `${action} code`,
      timestamp: new Date(),
      title: currentConv.title === `New ${activeMode} conversation` 
        ? `${action} ${language} code`
        : currentConv.title
    });

    if (!user) {
      toast({
        title: "Authentication Required", 
        description: "Please sign in to continue.",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);

    try {
      const messagesToSend = updatedCodeMessages.map(msg => ({
        role: msg.role,
        content: msg.content
      }));
      
      const aiResponse = await callAIService(messagesToSend, 'code');
      
      const assistantMessage: CodeMessage = {
        id: `msg_${Date.now()}_ai`,
        content: aiResponse,
        role: 'assistant',
        timestamp: new Date()
      };

      updateConversation(currentConv.id, {
        codeMessages: [...updatedCodeMessages, assistantMessage]
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to process code. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const currentConversation = getCurrentConversation();

  return (
    <div className="h-screen bg-background flex flex-col overflow-hidden">
      <Header />
      
      <div className="flex flex-1 overflow-hidden">
        <Sidebar
          conversations={conversations}
          activeConversationId={activeConversationId}
          onSelectConversation={setActiveConversationId}
          onNewConversation={createNewConversation}
          onDeleteConversation={deleteConversation}
          isCollapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        />
        
        <div className="flex-1 flex flex-col overflow-hidden">
          <ModeSelector activeMode={activeMode} onModeChange={setActiveMode} />
          
          {activeMode === 'chat' ? (
            <ChatInterface
              messages={currentConversation?.chatMessages || []}
              onSendMessage={handleSendMessage}
              isLoading={isLoading}
            />
          ) : (
            <CodeInterface
              messages={currentConversation?.codeMessages || []}
              onCodeAction={handleCodeAction}
              isLoading={isLoading}
            />
          )}
        </div>
      </div>
    </div>
  );
}