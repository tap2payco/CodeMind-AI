import { useEffect } from "react";
import { User, Bot, Copy, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useState } from "react";
import Prism from "prismjs";

// Import Prism language components
import "prismjs/components/prism-javascript";
import "prismjs/components/prism-typescript";
import "prismjs/components/prism-python";
import "prismjs/components/prism-java";
import "prismjs/components/prism-c";
import "prismjs/components/prism-cpp";
import "prismjs/components/prism-csharp";
import "prismjs/components/prism-rust";
import "prismjs/components/prism-go";
import "prismjs/components/prism-sql";
import "prismjs/components/prism-json";
import "prismjs/components/prism-yaml";
import "prismjs/components/prism-markdown";
import "prismjs/components/prism-bash";

// Import Prism dark theme
import "prismjs/themes/prism-tomorrow.css";

interface MessageProps {
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
  isThinking?: boolean;
}

export function Message({ content, role, timestamp, isThinking }: MessageProps) {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  useEffect(() => {
    // Highlight code blocks after rendering
    Prism.highlightAll();
  }, [content]);

  const copyToClipboard = async (text: string, codeId: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedCode(codeId);
      setTimeout(() => setCopiedCode(null), 2000);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  // Parse content to detect and highlight code blocks
  const parseContent = (text: string) => {
    const codeBlockRegex = /```(\w+)?\n([\s\S]*?)```/g;
    const parts = [];
    let lastIndex = 0;
    let match;

    while ((match = codeBlockRegex.exec(text)) !== null) {
      // Add text before code block
      if (match.index > lastIndex) {
        parts.push({ type: 'text', content: text.slice(lastIndex, match.index) });
      }
      
      // Add code block
      const language = match[1] || 'javascript';
      const code = match[2].trim();
      const codeId = `code-${Date.now()}-${Math.random()}`;
      
      parts.push({ 
        type: 'code', 
        content: code, 
        language,
        id: codeId
      });
      
      lastIndex = match.index + match[0].length;
    }
    
    // Add remaining text
    if (lastIndex < text.length) {
      parts.push({ type: 'text', content: text.slice(lastIndex) });
    }
    
    return parts.length > 0 ? parts : [{ type: 'text', content: text }];
  };

  const ThinkingIndicator = () => (
    <div className="flex items-center gap-1">
      <div className="flex gap-1">
        <div className="w-2 h-2 bg-primary rounded-full thinking-dot"></div>
        <div className="w-2 h-2 bg-primary rounded-full thinking-dot"></div>
        <div className="w-2 h-2 bg-primary rounded-full thinking-dot"></div>
      </div>
      <span className="text-xs text-muted-foreground ml-2">AI is thinking...</span>
    </div>
  );

  if (isThinking) {
    return (
      <div className="flex items-start gap-3 max-w-4xl">
        <div className="p-2 rounded-full bg-muted shrink-0">
          <Bot className="h-4 w-4" />
        </div>
        <div className="bg-muted rounded-lg p-4 min-w-0 flex-1">
          <ThinkingIndicator />
        </div>
      </div>
    );
  }

  const parsedContent = parseContent(content);

  return (
    <div className={cn(
      "flex items-start gap-3 max-w-4xl",
      role === 'user' ? "ml-auto flex-row-reverse" : ""
    )}>
      <div className={cn(
        "p-2 rounded-full shrink-0",
        role === 'user' 
          ? "bg-user-message text-white" 
          : "bg-muted"
      )}>
        {role === 'user' ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
      </div>
      
      <div className={cn(
        "rounded-lg p-4 min-w-0 flex-1",
        role === 'user' 
          ? "bg-user-message text-white" 
          : "bg-ai-message border border-border"
      )}>
        <div className="space-y-3">
          {parsedContent.map((part, index) => {
            if (part.type === 'text') {
              return (
                <div key={index} className="text-sm leading-relaxed whitespace-pre-wrap">
                  {part.content}
                </div>
              );
            } else if (part.type === 'code') {
              return (
                <div key={index} className="relative group">
                  <div className="flex items-center justify-between px-4 py-2 bg-code-bg border border-code-border rounded-t-lg">
                    <span className="text-xs text-muted-foreground font-mono">
                      {part.language}
                    </span>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 px-2 opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={() => copyToClipboard(part.content, part.id)}
                    >
                      {copiedCode === part.id ? (
                        <Check className="h-3 w-3 text-success" />
                      ) : (
                        <Copy className="h-3 w-3" />
                      )}
                    </Button>
                  </div>
                  <div className="bg-code-bg border-x border-b border-code-border rounded-b-lg overflow-x-auto">
                    <pre className="p-4 text-sm">
                      <code className={`language-${part.language}`}>
                        {part.content}
                      </code>
                    </pre>
                  </div>
                </div>
              );
            }
            return null;
          })}
        </div>
        
        <div className="mt-2 text-xs text-muted-foreground">
          {formatTime(timestamp)}
        </div>
      </div>
    </div>
  );
}