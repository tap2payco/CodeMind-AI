import { MessageCircle, Code2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface ModeSelectorProps {
  activeMode: 'chat' | 'code';
  onModeChange: (mode: 'chat' | 'code') => void;
}

export function ModeSelector({ activeMode, onModeChange }: ModeSelectorProps) {
  return (
    <div className="flex p-1 bg-muted rounded-lg m-4 mb-0">
      <Button
        variant="ghost"
        className={cn(
          "flex-1 gap-2 transition-all duration-200",
          activeMode === 'chat' 
            ? "bg-primary text-primary-foreground shadow-sm" 
            : "hover:bg-muted-foreground/10"
        )}
        onClick={() => onModeChange('chat')}
      >
        <MessageCircle className="h-4 w-4" />
        Chat Mode
      </Button>
      <Button
        variant="ghost"
        className={cn(
          "flex-1 gap-2 transition-all duration-200",
          activeMode === 'code' 
            ? "bg-success text-success-foreground shadow-sm" 
            : "hover:bg-muted-foreground/10"
        )}
        onClick={() => onModeChange('code')}
      >
        <Code2 className="h-4 w-4" />
        Code Mode
      </Button>
    </div>
  );
}