import { useState } from "react";
import { MessageSquare, Trash2, Plus, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";

interface Conversation {
  id: string;
  title: string;
  lastMessage: string;
  timestamp: Date;
  mode: 'chat' | 'code';
}

interface SidebarProps {
  conversations: Conversation[];
  activeConversationId: string | null;
  onSelectConversation: (id: string) => void;
  onNewConversation: () => void;
  onDeleteConversation: (id: string) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
}

export function Sidebar({
  conversations,
  activeConversationId,
  onSelectConversation,
  onNewConversation,
  onDeleteConversation,
  isCollapsed,
  onToggleCollapse
}: SidebarProps) {
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = diff / (1000 * 60 * 60);
    
    if (hours < 1) return 'Just now';
    if (hours < 24) return `${Math.floor(hours)}h ago`;
    return date.toLocaleDateString();
  };

  return (
    <div className={cn(
      "bg-card border-r border-border flex flex-col transition-all duration-300 ease-smooth",
      isCollapsed ? "w-16" : "w-80"
    )}>
      {/* Header */}
      <div className="p-4 border-b border-border flex items-center justify-between">
        {!isCollapsed && (
          <h2 className="text-sm font-semibold text-muted-foreground">Conversations</h2>
        )}
        <div className="flex items-center gap-1">
          {!isCollapsed && (
            <Button 
              variant="outline" 
              size="sm"
              onClick={onNewConversation}
              className="h-8 w-8 p-0"
            >
              <Plus className="h-4 w-4" />
            </Button>
          )}
          <Button 
            variant="ghost" 
            size="sm"
            onClick={onToggleCollapse}
            className="h-8 w-8 p-0"
          >
            {isCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      {/* Conversations List */}
      <ScrollArea className="flex-1">
        <div className="p-2 space-y-1">
          {conversations.map((conversation) => (
            <div
              key={conversation.id}
              className={cn(
                "group relative rounded-lg transition-all duration-200 cursor-pointer",
                "hover:bg-muted/50",
                activeConversationId === conversation.id && "bg-muted"
              )}
              onClick={() => onSelectConversation(conversation.id)}
              onMouseEnter={() => setHoveredId(conversation.id)}
              onMouseLeave={() => setHoveredId(null)}
            >
              <div className="p-3">
                <div className="flex items-start gap-3">
                  <div className={cn(
                    "p-1.5 rounded-md shrink-0",
                    conversation.mode === 'chat' ? "bg-primary/10 text-primary" : "bg-success/10 text-success"
                  )}>
                    <MessageSquare className="h-3 w-3" />
                  </div>
                  
                  {!isCollapsed && (
                    <div className="flex-1 min-w-0">
                      <div className="truncate text-sm font-medium text-foreground">
                        {conversation.title}
                      </div>
                      <div className="truncate text-xs text-muted-foreground mt-1">
                        {conversation.lastMessage}
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {formatTime(conversation.timestamp)}
                      </div>
                    </div>
                  )}
                </div>

                {/* Delete button */}
                {!isCollapsed && hoveredId === conversation.id && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="absolute top-2 right-2 h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteConversation(conversation.id);
                    }}
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                )}
              </div>
            </div>
          ))}

          {conversations.length === 0 && !isCollapsed && (
            <div className="text-center py-8 text-muted-foreground">
              <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No conversations yet</p>
              <p className="text-xs">Start by creating a new chat</p>
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}